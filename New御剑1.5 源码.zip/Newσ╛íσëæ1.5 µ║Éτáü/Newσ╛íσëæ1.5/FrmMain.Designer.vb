﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ListBox_Command = New System.Windows.Forms.ListBox()
        Me.ListBox_IP = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.ProgressBar_C = New System.Windows.Forms.ProgressBar()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox_StartIP = New System.Windows.Forms.TextBox()
        Me.TextBox_EndIP = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_Url = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.CheckBox_403 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_300 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_200 = New System.Windows.Forms.CheckBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.ListBox5 = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.Textbox24 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Textbox23 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.ListBox7 = New System.Windows.Forms.ListBox()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ListBox6 = New System.Windows.Forms.ListBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Timer_C = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.打开网址ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.复制网址ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.复制标题ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.导出内容ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.节点操作ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.展开节点ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.折叠节点ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.删除节点ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer_Scan = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.打开网址ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.复制网址ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.导出网址ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer_SQL = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.ItemSize = New System.Drawing.Size(110, 21)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(784, 512)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.TreeView1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.ListBox_Command)
        Me.TabPage1.Controls.Add(Me.ListBox_IP)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.CheckBox3)
        Me.TabPage1.Controls.Add(Me.CheckBox2)
        Me.TabPage1.Controls.Add(Me.CheckBox1)
        Me.TabPage1.Controls.Add(Me.ProgressBar_C)
        Me.TabPage1.Controls.Add(Me.RadioButton3)
        Me.TabPage1.Controls.Add(Me.RadioButton2)
        Me.TabPage1.Controls.Add(Me.RadioButton1)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.TextBox_StartIP)
        Me.TabPage1.Controls.Add(Me.TextBox_EndIP)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.TextBox_Url)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(776, 483)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "绑定域名查询"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TreeView1
        '
        Me.TreeView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView1.Location = New System.Drawing.Point(8, 106)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Size = New System.Drawing.Size(756, 338)
        Me.TreeView1.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(669, 91)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 12)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "节点：0个"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(551, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 12)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "数据：0条"
        '
        'ListBox_Command
        '
        Me.ListBox_Command.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox_Command.FormattingEnabled = True
        Me.ListBox_Command.ItemHeight = 12
        Me.ListBox_Command.Location = New System.Drawing.Point(633, 115)
        Me.ListBox_Command.Name = "ListBox_Command"
        Me.ListBox_Command.Size = New System.Drawing.Size(120, 24)
        Me.ListBox_Command.TabIndex = 23
        '
        'ListBox_IP
        '
        Me.ListBox_IP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox_IP.FormattingEnabled = True
        Me.ListBox_IP.ItemHeight = 12
        Me.ListBox_IP.Location = New System.Drawing.Point(439, 10)
        Me.ListBox_IP.Name = "ListBox_IP"
        Me.ListBox_IP.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox_IP.Size = New System.Drawing.Size(325, 50)
        Me.ListBox_IP.TabIndex = 22
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(437, 91)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 12)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "耗时：0秒"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 91)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 12)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "指令：准备就绪..."
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(671, 68)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(96, 16)
        Me.CheckBox3.TabIndex = 19
        Me.CheckBox3.Text = "导出时带标题"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(553, 68)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(108, 16)
        Me.CheckBox2.TabIndex = 18
        Me.CheckBox2.Text = "验证IP是否变化"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(439, 68)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(108, 16)
        Me.CheckBox1.TabIndex = 15
        Me.CheckBox1.Text = "探测服务器信息"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'ProgressBar_C
        '
        Me.ProgressBar_C.Location = New System.Drawing.Point(9, 450)
        Me.ProgressBar_C.Name = "ProgressBar_C"
        Me.ProgressBar_C.Size = New System.Drawing.Size(755, 20)
        Me.ProgressBar_C.TabIndex = 13
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(281, 68)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(71, 16)
        Me.RadioButton3.TabIndex = 11
        Me.RadioButton3.Text = "自由查询"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(281, 41)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(71, 16)
        Me.RadioButton2.TabIndex = 10
        Me.RadioButton2.Text = "多服务器"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(281, 14)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(71, 16)
        Me.RadioButton1.TabIndex = 9
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "单服务器"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Location = New System.Drawing.Point(355, 64)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "停止查询"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(355, 37)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "开始查询"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(355, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "获取IP"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox_StartIP
        '
        Me.TextBox_StartIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox_StartIP.Enabled = False
        Me.TextBox_StartIP.Location = New System.Drawing.Point(41, 37)
        Me.TextBox_StartIP.Name = "TextBox_StartIP"
        Me.TextBox_StartIP.Size = New System.Drawing.Size(234, 21)
        Me.TextBox_StartIP.TabIndex = 2
        Me.TextBox_StartIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_EndIP
        '
        Me.TextBox_EndIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox_EndIP.Enabled = False
        Me.TextBox_EndIP.Location = New System.Drawing.Point(41, 64)
        Me.TextBox_EndIP.Name = "TextBox_EndIP"
        Me.TextBox_EndIP.Size = New System.Drawing.Size(234, 21)
        Me.TextBox_EndIP.TabIndex = 3
        Me.TextBox_EndIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "结束："
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "开始："
        '
        'TextBox_Url
        '
        Me.TextBox_Url.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox_Url.Location = New System.Drawing.Point(41, 10)
        Me.TextBox_Url.Name = "TextBox_Url"
        Me.TextBox_Url.Size = New System.Drawing.Size(234, 21)
        Me.TextBox_Url.TabIndex = 1
        Me.TextBox_Url.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "域名："
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.Button12)
        Me.TabPage2.Controls.Add(Me.ComboBox3)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Button11)
        Me.TabPage2.Controls.Add(Me.Button10)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.ComboBox2)
        Me.TabPage2.Controls.Add(Me.ComboBox1)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.ListBox3)
        Me.TabPage2.Controls.Add(Me.CheckBox_403)
        Me.TabPage2.Controls.Add(Me.CheckBox_300)
        Me.TabPage2.Controls.Add(Me.CheckBox_200)
        Me.TabPage2.Controls.Add(Me.ListBox2)
        Me.TabPage2.Controls.Add(Me.Button9)
        Me.TabPage2.Controls.Add(Me.Button8)
        Me.TabPage2.Controls.Add(Me.Button7)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Controls.Add(Me.ListView1)
        Me.TabPage2.Controls.Add(Me.ProgressBar1)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.Button4)
        Me.TabPage2.Controls.Add(Me.ListBox1)
        Me.TabPage2.Controls.Add(Me.TextBox1)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(776, 483)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "批量扫描后台"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(105, 451)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(46, 23)
        Me.Button12.TabIndex = 53
        Me.Button12.Text = "清空"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(190, 35)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(120, 20)
        Me.ComboBox3.TabIndex = 51
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(155, 39)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 12)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "模式"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(9, 33)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(140, 23)
        Me.Button11.TabIndex = 49
        Me.Button11.Text = "外部导入域名列表"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(9, 6)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(141, 23)
        Me.Button10.TabIndex = 48
        Me.Button10.Text = "吸取绑定域名列表"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(652, 59)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 12)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "扫描速度：0/每秒"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(345, 36)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(48, 20)
        Me.ComboBox2.TabIndex = 45
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(426, 35)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(48, 20)
        Me.ComboBox1.TabIndex = 44
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(316, 40)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 12)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "线程"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(397, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 12)
        Me.Label12.TabIndex = 41
        Me.Label12.Text = "超时"
        '
        'ListBox3
        '
        Me.ListBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 12
        Me.ListBox3.Location = New System.Drawing.Point(654, 6)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(113, 50)
        Me.ListBox3.TabIndex = 40
        '
        'CheckBox_403
        '
        Me.CheckBox_403.AutoSize = True
        Me.CheckBox_403.Location = New System.Drawing.Point(480, 39)
        Me.CheckBox_403.Name = "CheckBox_403"
        Me.CheckBox_403.Size = New System.Drawing.Size(42, 16)
        Me.CheckBox_403.TabIndex = 39
        Me.CheckBox_403.Text = "403"
        Me.CheckBox_403.UseVisualStyleBackColor = True
        '
        'CheckBox_300
        '
        Me.CheckBox_300.AutoSize = True
        Me.CheckBox_300.Location = New System.Drawing.Point(480, 22)
        Me.CheckBox_300.Name = "CheckBox_300"
        Me.CheckBox_300.Size = New System.Drawing.Size(42, 16)
        Me.CheckBox_300.TabIndex = 38
        Me.CheckBox_300.Text = "3xx"
        Me.CheckBox_300.UseVisualStyleBackColor = True
        '
        'CheckBox_200
        '
        Me.CheckBox_200.AutoSize = True
        Me.CheckBox_200.Checked = True
        Me.CheckBox_200.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_200.Location = New System.Drawing.Point(480, 6)
        Me.CheckBox_200.Name = "CheckBox_200"
        Me.CheckBox_200.Size = New System.Drawing.Size(42, 16)
        Me.CheckBox_200.TabIndex = 37
        Me.CheckBox_200.Text = "200"
        Me.CheckBox_200.UseVisualStyleBackColor = True
        '
        'ListBox2
        '
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.HorizontalScrollbar = True
        Me.ListBox2.ItemHeight = 12
        Me.ListBox2.Location = New System.Drawing.Point(524, 6)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(113, 50)
        Me.ListBox2.TabIndex = 36
        '
        'Button9
        '
        Me.Button9.Enabled = False
        Me.Button9.Location = New System.Drawing.Point(399, 6)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 31
        Me.Button9.Text = "暂停扫描"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Enabled = False
        Me.Button8.Location = New System.Drawing.Point(318, 6)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 23)
        Me.Button8.TabIndex = 30
        Me.Button8.Text = "继续扫描"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Enabled = False
        Me.Button7.Location = New System.Drawing.Point(237, 6)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 29
        Me.Button7.Text = "停止扫描"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(156, 6)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 28
        Me.Button6.Text = "开始扫描"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListView1.Location = New System.Drawing.Point(156, 75)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(611, 374)
        Me.ListView1.TabIndex = 27
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(156, 452)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(611, 22)
        Me.ProgressBar1.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 60)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(71, 12)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "作业数量：0"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(55, 451)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(46, 23)
        Me.Button5.TabIndex = 25
        Me.Button5.Text = "删除"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(6, 451)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(45, 23)
        Me.Button4.TabIndex = 24
        Me.Button4.Text = "添加"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.HorizontalScrollbar = True
        Me.ListBox1.ItemHeight = 12
        Me.ListBox1.Location = New System.Drawing.Point(7, 75)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox1.Size = New System.Drawing.Size(143, 374)
        Me.ListBox1.TabIndex = 23
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(156, 59)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(481, 12)
        Me.TextBox1.TabIndex = 35
        Me.TextBox1.Text = "扫描信息：准备就绪..."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(638, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 48)
        Me.Label9.TabIndex = 52
        Me.Label9.Text = "双" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "击" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "操" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "作"
        '
        'TabPage3
        '
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.TextBox7)
        Me.TabPage3.Controls.Add(Me.TextBox6)
        Me.TabPage3.Controls.Add(Me.ProgressBar2)
        Me.TabPage3.Controls.Add(Me.Label18)
        Me.TabPage3.Controls.Add(Me.ListView2)
        Me.TabPage3.Controls.Add(Me.Label17)
        Me.TabPage3.Controls.Add(Me.TextBox3)
        Me.TabPage3.Controls.Add(Me.TextBox2)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.Label15)
        Me.TabPage3.Controls.Add(Me.ComboBox5)
        Me.TabPage3.Controls.Add(Me.ComboBox4)
        Me.TabPage3.Controls.Add(Me.TextBox5)
        Me.TabPage3.Controls.Add(Me.TextBox4)
        Me.TabPage3.Controls.Add(Me.Button19)
        Me.TabPage3.Controls.Add(Me.Button18)
        Me.TabPage3.Controls.Add(Me.Button13)
        Me.TabPage3.Controls.Add(Me.Button14)
        Me.TabPage3.Controls.Add(Me.Button15)
        Me.TabPage3.Controls.Add(Me.Label14)
        Me.TabPage3.Controls.Add(Me.Button16)
        Me.TabPage3.Controls.Add(Me.Button17)
        Me.TabPage3.Controls.Add(Me.ListBox4)
        Me.TabPage3.Controls.Add(Me.ListBox5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(776, 483)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "批量检测注入"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Enabled = False
        Me.TextBox7.Location = New System.Drawing.Point(156, 251)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(449, 12)
        Me.TextBox7.TabIndex = 78
        Me.TextBox7.Text = "检测信息：准备就绪..."
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Enabled = False
        Me.TextBox6.Location = New System.Drawing.Point(156, 60)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(449, 12)
        Me.TextBox6.TabIndex = 77
        Me.TextBox6.Text = "采集信息：准备就绪..."
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(156, 451)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(611, 22)
        Me.ProgressBar2.TabIndex = 76
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(606, 251)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(131, 12)
        Me.Label18.TabIndex = 75
        Me.Label18.Text = "可能存在注入的地址：0"
        '
        'ListView2
        '
        Me.ListView2.ForeColor = System.Drawing.Color.Red
        Me.ListView2.Location = New System.Drawing.Point(156, 266)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(611, 183)
        Me.ListView2.TabIndex = 73
        Me.ListView2.UseCompatibleStateImageBehavior = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(606, 60)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(107, 12)
        Me.Label17.TabIndex = 72
        Me.Label17.Text = "已经采集的地址：0"
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Location = New System.Drawing.Point(267, 33)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(279, 21)
        Me.TextBox3.TabIndex = 64
        Me.TextBox3.Text = " aND 2=3"
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(267, 7)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(279, 21)
        Me.TextBox2.TabIndex = 63
        Me.TextBox2.Text = " aND 2=2"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(552, 38)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 12)
        Me.Label16.TabIndex = 71
        Me.Label16.Text = "工作线程"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(552, 10)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(53, 12)
        Me.Label15.TabIndex = 70
        Me.Label15.Text = "每站采集"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(608, 34)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(54, 20)
        Me.ComboBox5.TabIndex = 69
        Me.ComboBox5.Text = "20"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(608, 7)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(54, 20)
        Me.ComboBox4.TabIndex = 2
        Me.ComboBox4.Text = "10"
        '
        'TextBox5
        '
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox5.Location = New System.Drawing.Point(156, 33)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(105, 21)
        Me.TextBox5.TabIndex = 68
        Me.TextBox5.Text = "构造语句二：不等"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox4
        '
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.Location = New System.Drawing.Point(156, 7)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(105, 21)
        Me.TextBox4.TabIndex = 67
        Me.TextBox4.Text = "构造语句一：等于"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button19
        '
        Me.Button19.Enabled = False
        Me.Button19.Location = New System.Drawing.Point(668, 33)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(99, 23)
        Me.Button19.TabIndex = 62
        Me.Button19.Text = "停止检测"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button18.Location = New System.Drawing.Point(668, 6)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(99, 23)
        Me.Button18.TabIndex = 61
        Me.Button18.Text = "开始检测"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(105, 451)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(46, 23)
        Me.Button13.TabIndex = 60
        Me.Button13.Text = "清空"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(9, 33)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(140, 23)
        Me.Button14.TabIndex = 59
        Me.Button14.Text = "外部导入域名列表"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(9, 6)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(141, 23)
        Me.Button15.TabIndex = 58
        Me.Button15.Text = "吸取绑定域名列表"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 60)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(71, 12)
        Me.Label14.TabIndex = 57
        Me.Label14.Text = "作业数量：0"
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(55, 451)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(46, 23)
        Me.Button16.TabIndex = 56
        Me.Button16.Text = "删除"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(6, 451)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(45, 23)
        Me.Button17.TabIndex = 55
        Me.Button17.Text = "添加"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'ListBox4
        '
        Me.ListBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.HorizontalScrollbar = True
        Me.ListBox4.ItemHeight = 12
        Me.ListBox4.Location = New System.Drawing.Point(7, 75)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox4.Size = New System.Drawing.Size(143, 374)
        Me.ListBox4.TabIndex = 54
        '
        'ListBox5
        '
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.ItemHeight = 12
        Me.ListBox5.Location = New System.Drawing.Point(156, 75)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(611, 172)
        Me.ListBox5.TabIndex = 74
        '
        'TabPage4
        '
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.CheckBox4)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.Label26)
        Me.TabPage4.Controls.Add(Me.CheckBox7)
        Me.TabPage4.Controls.Add(Me.CheckBox6)
        Me.TabPage4.Controls.Add(Me.CheckBox5)
        Me.TabPage4.Controls.Add(Me.TextBox30)
        Me.TabPage4.Controls.Add(Me.TextBox27)
        Me.TabPage4.Controls.Add(Me.Label21)
        Me.TabPage4.Controls.Add(Me.Label22)
        Me.TabPage4.Controls.Add(Me.TextBox28)
        Me.TabPage4.Controls.Add(Me.TextBox25)
        Me.TabPage4.Controls.Add(Me.Label19)
        Me.TabPage4.Controls.Add(Me.Label20)
        Me.TabPage4.Controls.Add(Me.TextBox26)
        Me.TabPage4.Controls.Add(Me.Textbox24)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.Textbox23)
        Me.TabPage4.Controls.Add(Me.Label25)
        Me.TabPage4.Controls.Add(Me.TextBox22)
        Me.TabPage4.Controls.Add(Me.TextBox29)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(776, 483)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "多种编码转换"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(720, 362)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox4.TabIndex = 86
        Me.CheckBox4.Text = "还原"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(9, 365)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(53, 12)
        Me.Label27.TabIndex = 85
        Me.Label27.Text = "BASE64："
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(389, 365)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(65, 12)
        Me.Label26.TabIndex = 84
        Me.Label26.Text = "雷池编码："
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(340, 362)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox7.TabIndex = 83
        Me.CheckBox7.Text = "还原"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(720, 256)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox6.TabIndex = 82
        Me.CheckBox6.Text = "大写"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(340, 256)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox5.TabIndex = 81
        Me.CheckBox5.Text = "大写"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(11, 378)
        Me.TextBox30.Multiline = True
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox30.Size = New System.Drawing.Size(370, 90)
        Me.TextBox30.TabIndex = 79
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(391, 272)
        Me.TextBox27.Multiline = True
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox27.Size = New System.Drawing.Size(370, 90)
        Me.TextBox27.TabIndex = 78
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(389, 259)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(53, 12)
        Me.Label21.TabIndex = 77
        Me.Label21.Text = "MD5-16："
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(9, 259)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 12)
        Me.Label22.TabIndex = 76
        Me.Label22.Text = "MD5-32："
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(11, 272)
        Me.TextBox28.Multiline = True
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox28.Size = New System.Drawing.Size(370, 90)
        Me.TextBox28.TabIndex = 75
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(391, 166)
        Me.TextBox25.Multiline = True
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox25.Size = New System.Drawing.Size(370, 90)
        Me.TextBox25.TabIndex = 74
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(389, 153)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 12)
        Me.Label19.TabIndex = 73
        Me.Label19.Text = "ASC编码："
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(9, 153)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(59, 12)
        Me.Label20.TabIndex = 72
        Me.Label20.Text = "HEX编码："
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(11, 166)
        Me.TextBox26.Multiline = True
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox26.Size = New System.Drawing.Size(370, 90)
        Me.TextBox26.TabIndex = 71
        '
        'Textbox24
        '
        Me.Textbox24.Location = New System.Drawing.Point(391, 60)
        Me.Textbox24.Multiline = True
        Me.Textbox24.Name = "Textbox24"
        Me.Textbox24.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Textbox24.Size = New System.Drawing.Size(370, 90)
        Me.Textbox24.TabIndex = 70
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(389, 45)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 12)
        Me.Label23.TabIndex = 69
        Me.Label23.Text = "SQL编码："
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(9, 45)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(59, 12)
        Me.Label24.TabIndex = 68
        Me.Label24.Text = "URL编码："
        '
        'Textbox23
        '
        Me.Textbox23.Location = New System.Drawing.Point(11, 60)
        Me.Textbox23.Multiline = True
        Me.Textbox23.Name = "Textbox23"
        Me.Textbox23.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Textbox23.Size = New System.Drawing.Size(370, 90)
        Me.Textbox23.TabIndex = 67
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(9, 6)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 12)
        Me.Label25.TabIndex = 66
        Me.Label25.Text = "要转的："
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(11, 21)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox22.Size = New System.Drawing.Size(750, 21)
        Me.TextBox22.TabIndex = 65
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(391, 378)
        Me.TextBox29.Multiline = True
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox29.Size = New System.Drawing.Size(370, 90)
        Me.TextBox29.TabIndex = 80
        '
        'TabPage5
        '
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.Label35)
        Me.TabPage5.Controls.Add(Me.Button24)
        Me.TabPage5.Controls.Add(Me.Label34)
        Me.TabPage5.Controls.Add(Me.TextBox11)
        Me.TabPage5.Controls.Add(Me.TextBox12)
        Me.TabPage5.Controls.Add(Me.Label33)
        Me.TabPage5.Controls.Add(Me.Label32)
        Me.TabPage5.Controls.Add(Me.TextBox10)
        Me.TabPage5.Controls.Add(Me.Label31)
        Me.TabPage5.Controls.Add(Me.Button23)
        Me.TabPage5.Controls.Add(Me.TextBox8)
        Me.TabPage5.Controls.Add(Me.Label30)
        Me.TabPage5.Controls.Add(Me.Button22)
        Me.TabPage5.Controls.Add(Me.ListBox7)
        Me.TabPage5.Controls.Add(Me.ProgressBar3)
        Me.TabPage5.Controls.Add(Me.Label29)
        Me.TabPage5.Controls.Add(Me.ListBox6)
        Me.TabPage5.Controls.Add(Me.Label28)
        Me.TabPage5.Controls.Add(Me.Button21)
        Me.TabPage5.Controls.Add(Me.Button20)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(776, 483)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "MD5解密相关"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(720, 462)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(47, 12)
        Me.Label35.TabIndex = 114
        Me.Label35.Text = "Label35"
        Me.Label35.Visible = False
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(692, 115)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(75, 23)
        Me.Button24.TabIndex = 113
        Me.Button24.Text = "暂时未开"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(372, 141)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(41, 12)
        Me.Label34.TabIndex = 112
        Me.Label34.Text = "结果："
        '
        'TextBox11
        '
        Me.TextBox11.Enabled = False
        Me.TextBox11.Location = New System.Drawing.Point(374, 156)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(393, 21)
        Me.TextBox11.TabIndex = 111
        '
        'TextBox12
        '
        Me.TextBox12.Enabled = False
        Me.TextBox12.Location = New System.Drawing.Point(374, 117)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(307, 21)
        Me.TextBox12.TabIndex = 110
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(372, 102)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(101, 12)
        Me.Label33.TabIndex = 109
        Me.Label33.Text = "哈客内部解密接口"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(372, 53)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(41, 12)
        Me.Label32.TabIndex = 108
        Me.Label32.Text = "结果："
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(374, 68)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(393, 21)
        Me.TextBox10.TabIndex = 107
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("宋体", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label31.Location = New System.Drawing.Point(438, 246)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(259, 20)
        Me.Label31.TabIndex = 106
        Me.Label31.Text = "MD5其他在线接口，在编码中"
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(692, 27)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(75, 23)
        Me.Button23.TabIndex = 105
        Me.Button23.Text = "解密"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(374, 29)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(307, 21)
        Me.TextBox8.TabIndex = 104
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(372, 14)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(143, 12)
        Me.Label30.TabIndex = 103
        Me.Label30.Text = "国内在线MD5免费解密接口"
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(251, 9)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(100, 23)
        Me.Button22.TabIndex = 102
        Me.Button22.Text = "导出结果"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'ListBox7
        '
        Me.ListBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox7.FormattingEnabled = True
        Me.ListBox7.HorizontalScrollbar = True
        Me.ListBox7.ItemHeight = 12
        Me.ListBox7.Location = New System.Drawing.Point(8, 262)
        Me.ListBox7.Name = "ListBox7"
        Me.ListBox7.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox7.Size = New System.Drawing.Size(343, 182)
        Me.ListBox7.TabIndex = 101
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(6, 451)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(345, 23)
        Me.ProgressBar3.TabIndex = 100
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(5, 246)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(71, 12)
        Me.Label29.TabIndex = 99
        Me.Label29.Text = "解密结果：0"
        '
        'ListBox6
        '
        Me.ListBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.HorizontalScrollbar = True
        Me.ListBox6.ItemHeight = 12
        Me.ListBox6.Location = New System.Drawing.Point(7, 50)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox6.Size = New System.Drawing.Size(344, 194)
        Me.ListBox6.TabIndex = 98
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(5, 35)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(71, 12)
        Me.Label28.TabIndex = 95
        Me.Label28.Text = "解密序列：0"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(129, 9)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(116, 23)
        Me.Button21.TabIndex = 97
        Me.Button21.Text = "开始批量解密"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(7, 9)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(116, 23)
        Me.Button20.TabIndex = 96
        Me.Button20.Text = "导入32位MD5序列"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage6.Controls.Add(Me.TextBox9)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(776, 483)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "系统信息"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(0, 0)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(775, 482)
        Me.TextBox9.TabIndex = 0
        '
        'Timer_C
        '
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.打开网址ToolStripMenuItem, Me.复制网址ToolStripMenuItem, Me.复制标题ToolStripMenuItem, Me.ToolStripSeparator2, Me.导出内容ToolStripMenuItem, Me.ToolStripSeparator1, Me.节点操作ToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(125, 126)
        '
        '打开网址ToolStripMenuItem
        '
        Me.打开网址ToolStripMenuItem.Name = "打开网址ToolStripMenuItem"
        Me.打开网址ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.打开网址ToolStripMenuItem.Text = "打开网址"
        '
        '复制网址ToolStripMenuItem
        '
        Me.复制网址ToolStripMenuItem.Name = "复制网址ToolStripMenuItem"
        Me.复制网址ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.复制网址ToolStripMenuItem.Text = "复制网址"
        '
        '复制标题ToolStripMenuItem
        '
        Me.复制标题ToolStripMenuItem.Name = "复制标题ToolStripMenuItem"
        Me.复制标题ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.复制标题ToolStripMenuItem.Text = "复制标题"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(121, 6)
        '
        '导出内容ToolStripMenuItem
        '
        Me.导出内容ToolStripMenuItem.Name = "导出内容ToolStripMenuItem"
        Me.导出内容ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.导出内容ToolStripMenuItem.Text = "导出内容"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(121, 6)
        '
        '节点操作ToolStripMenuItem
        '
        Me.节点操作ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.展开节点ToolStripMenuItem, Me.ToolStripSeparator3, Me.折叠节点ToolStripMenuItem, Me.ToolStripSeparator4, Me.删除节点ToolStripMenuItem})
        Me.节点操作ToolStripMenuItem.Name = "节点操作ToolStripMenuItem"
        Me.节点操作ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.节点操作ToolStripMenuItem.Text = "节点操作"
        '
        '展开节点ToolStripMenuItem
        '
        Me.展开节点ToolStripMenuItem.Name = "展开节点ToolStripMenuItem"
        Me.展开节点ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.展开节点ToolStripMenuItem.Text = "展开节点"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(121, 6)
        '
        '折叠节点ToolStripMenuItem
        '
        Me.折叠节点ToolStripMenuItem.Name = "折叠节点ToolStripMenuItem"
        Me.折叠节点ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.折叠节点ToolStripMenuItem.Text = "折叠节点"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(121, 6)
        '
        '删除节点ToolStripMenuItem
        '
        Me.删除节点ToolStripMenuItem.Name = "删除节点ToolStripMenuItem"
        Me.删除节点ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.删除节点ToolStripMenuItem.Text = "删除节点"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer_Scan
        '
        Me.Timer_Scan.Interval = 1000
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.打开网址ToolStripMenuItem1, Me.复制网址ToolStripMenuItem1, Me.导出网址ToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(125, 70)
        '
        '打开网址ToolStripMenuItem1
        '
        Me.打开网址ToolStripMenuItem1.Name = "打开网址ToolStripMenuItem1"
        Me.打开网址ToolStripMenuItem1.Size = New System.Drawing.Size(124, 22)
        Me.打开网址ToolStripMenuItem1.Text = "打开网址"
        '
        '复制网址ToolStripMenuItem1
        '
        Me.复制网址ToolStripMenuItem1.Name = "复制网址ToolStripMenuItem1"
        Me.复制网址ToolStripMenuItem1.Size = New System.Drawing.Size(124, 22)
        Me.复制网址ToolStripMenuItem1.Text = "复制网址"
        '
        '导出网址ToolStripMenuItem
        '
        Me.导出网址ToolStripMenuItem.Name = "导出网址ToolStripMenuItem"
        Me.导出网址ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.导出网址ToolStripMenuItem.Text = "导出内容"
        '
        'Timer_SQL
        '
        Me.Timer_SQL.Interval = 500
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(784, 512)
        Me.Controls.Add(Me.TabControl1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FrmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FormMain"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox_Url As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_StartIP As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_EndIP As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents ProgressBar_C As System.Windows.Forms.ProgressBar
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ListBox_IP As System.Windows.Forms.ListBox
    Friend WithEvents ListBox_Command As System.Windows.Forms.ListBox
    Friend WithEvents Timer_C As System.Windows.Forms.Timer
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents 打开网址ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 复制网址ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 复制标题ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 导出内容ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents 节点操作ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 展开节点ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 折叠节点ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 删除节点ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents CheckBox_200 As System.Windows.Forms.CheckBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents CheckBox_403 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_300 As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Timer_Scan As System.Windows.Forms.Timer
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents 打开网址ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 复制网址ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 导出网址ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Timer_SQL As System.Windows.Forms.Timer
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Textbox24 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Textbox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox7 As System.Windows.Forms.ListBox
    Friend WithEvents ProgressBar3 As System.Windows.Forms.ProgressBar
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label

End Class
